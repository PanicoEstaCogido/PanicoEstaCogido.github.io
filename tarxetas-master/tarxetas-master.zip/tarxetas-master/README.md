<img src="https://irocho.github.io/imaxes/logo.png" alt="" />

# Traballando con HTML+CSS

Neste exercicio tes que modificar todo o que poidas para demostrar que entendes todas as etiquetas, propiedades, atributos,...

Arriba á dereita tes a opción de __clonar ou descargar__ a carpeta para traballar en local no teu ordenador. O contido non é moi especial:

* index.html
* estilo.css


Orixinalmente [atopeino aquí](http://designwoop.com/2013/12/30-open-source-css3-code-samples-web-developers/) pero fun tuneando paseniño unha das dúas versións

Orixe: [este artigo de i-rochiño](https://wp.me/p2OwJM-1ak)
